Pipeline Diagrams icon pack - https://pipeline-diagrams.com/templates.html

dark-lines/   icons for light backgrounds
light-lines/  icons for dark backgrounds

PowerPoint: Insert > Pictures, then right click > Convert to Shape to edit
lines and colors. Add letter codes and names as text boxes.
Keynote: drag the SVG in. Miro: upload as custom shapes (paid plans) or as
images. Lucidchart: Shapes > Import SVG.
